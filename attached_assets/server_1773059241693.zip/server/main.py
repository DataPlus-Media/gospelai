from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers.mobile import router as mobile_router
from routers.usage import router as usage_router
from routers.revenuecat import router as rc_router

app = FastAPI(title="GospelAI Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"ok": True, "message": "GospelAI server is alive"}

@app.get("/api/health")
def health():
    return {"ok": True}

# existing mobile/chat routes
app.include_router(mobile_router, prefix="/api")
# add usage + rc webhook routes at root
app.include_router(usage_router)
app.include_router(rc_router)

if __name__ == "__main__":
    import os, uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
