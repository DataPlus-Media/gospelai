import os, httpx

RC_SECRET = os.getenv("REVENUECAT_SECRET_API_KEY")

async def fetch_subscriber(app_user_id: str) -> dict | None:
    if not RC_SECRET:
        return None
    headers = {"Authorization": f"Bearer {RC_SECRET}"}
    url = f"https://api.revenuecat.com/v1/subscribers/{app_user_id}"
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(url, headers=headers)
        if r.status_code == 200:
            return r.json()
        return None

def is_pro_from_payload(subscriber_json: dict) -> bool:
    ent = (subscriber_json or {}).get("subscriber", {}).get("entitlements", {})
    return bool(ent.get("pro", {}).get("active"))
