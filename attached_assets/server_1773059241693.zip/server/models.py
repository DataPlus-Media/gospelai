from sqlalchemy import Column, Integer, String, Date, Boolean, UniqueConstraint
from db import Base  # absolute import; matches uvicorn main:app

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    app_user_id = Column(String, unique=True, index=True)
    rc_pro = Column(Boolean, default=False)

class Usage(Base):
    __tablename__ = "usage"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    day = Column(Date, index=True)
    count = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("user_id", "day", name="uq_usage_day"),)
