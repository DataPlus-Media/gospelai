from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session
from db import get_db
from models import User

# Minimal: trust Clerk to send Authorization; we use the Clerk user id if provided by UI.
# If not signed-in, allow anonymous via X-Device-Id (front-end can send a stable ID).
async def get_current_app_user_id(
    db: Session = Depends(get_db),
    authorization: str | None = Header(default=None),
    x_device_id: str | None = Header(default=None),
) -> str:
    # If you pass Clerk user id from the app in a custom header, prefer that:
    # e.g. 'X-App-User-Id: {clerkUserId}'
    # For now, parse a simple "Bearer {userId}" fallback used by client, else use device id.
    uid = None
    if authorization and authorization.lower().startswith("bearer "):
        # In production, VERIFY this JWT via Clerk JWKS.
        token = authorization.split(" ", 1)[1].strip()
        if token and len(token) < 128:  # crude: treat short token as "user id" sent by client
            uid = token
    if not uid and x_device_id:
        uid = f"anon:{x_device_id}"
    if not uid:
        # final fallback: guest bucket per IP would require request.client.host
        raise HTTPException(status_code=401, detail="Missing user identity")

    # Upsert user
    user = db.query(User).filter(User.app_user_id == uid).first()
    if not user:
        user = User(app_user_id=uid, rc_pro=False)
        db.add(user)
        db.commit()
        db.refresh(user)
    return uid

def get_user_record(uid: str, db: Session) -> User:
    user = db.query(User).filter(User.app_user_id == uid).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
