from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from db import get_db
from models import User, Usage
from auth import get_current_app_user_id, get_user_record

router = APIRouter()
DAILY_LIMIT = 10

@router.post("/usage/can-send")
def can_send(
    db: Session = Depends(get_db),
    uid: str = Depends(get_current_app_user_id),
):
    user: User = get_user_record(uid, db)

    if user.rc_pro:
        return {"ok": True}

    today = date.today()
    # get-or-create Usage
    u = db.query(Usage).filter(Usage.user_id == user.id, Usage.day == today).first()
    if not u:
        u = Usage(user_id=user.id, day=today, count=0)
        db.add(u)
        db.commit()
        db.refresh(u)

    if u.count >= DAILY_LIMIT:
        raise HTTPException(status_code=402, detail="Payment required")

    u.count += 1
    db.commit()
    return {"ok": True}
