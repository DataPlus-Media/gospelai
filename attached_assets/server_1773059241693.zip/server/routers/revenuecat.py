from fastapi import APIRouter, Request, Response, Depends
from sqlalchemy.orm import Session
from db import get_db
from models import User
from services.revenuecat import fetch_subscriber, is_pro_from_payload

router = APIRouter()

@router.post("/webhooks/revenuecat")
async def revenuecat_webhook(req: Request, db: Session = Depends(get_db)):
    data = await req.json()
    # app_user_id may be at top-level or nested in event; handle both
    app_user_id = data.get("app_user_id") or data.get("event", {}).get("app_user_id")
    if not app_user_id:
        return Response(status_code=204)

    sub = await fetch_subscriber(app_user_id)
    if not sub:
        return Response(status_code=200)

    is_pro = is_pro_from_payload(sub)
    user = db.query(User).filter(User.app_user_id == app_user_id).first()
    if not user:
        user = User(app_user_id=app_user_id, rc_pro=is_pro)
        db.add(user)
    else:
        user.rc_pro = is_pro
    db.commit()
    return Response(status_code=200)
