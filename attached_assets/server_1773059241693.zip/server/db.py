import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

DATABASE_URL = os.getenv("DATABASE_URL")
# If your Postgres requires TLS and the URL lacks it, uncomment:
# if DATABASE_URL and "sslmode=" not in DATABASE_URL:
#     DATABASE_URL += "?sslmode=require"

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    """Declarative base for ORM models."""
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
